/**
 * Java & Distributed Systems (ITJA321) Assignment Question 1.
 *
 * @author Matthew Van der Bijl (xq9x3wv31)
 */
package assigment.q1;
