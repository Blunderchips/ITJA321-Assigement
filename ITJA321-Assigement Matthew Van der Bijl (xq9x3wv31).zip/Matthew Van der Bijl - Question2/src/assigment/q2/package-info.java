/**
 * Java & Distributed Systems (ITJA321) Assignment Question 2.
 *
 * @author Matthew Van der Bijl (xq9x3wv31)
 */
package assigment.q2;